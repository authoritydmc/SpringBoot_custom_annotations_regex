package com.example.ussample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsSampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
